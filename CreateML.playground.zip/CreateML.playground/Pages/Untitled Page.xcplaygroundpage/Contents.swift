import Foundation
import CreateML
import CoreML


struct TennisDataSample: MLDataValueConvertible {
    
    static var dataValueType: MLDataValue.ValueType {
        return .double
    }
    
    
    let dataValue: MLDataValue
    
    init?(from dataValue: MLDataValue) {
        self.dataValue = dataValue
    }
    
    init() {
        self.dataValue = MLDataValue.double(0.0)
    }
    
    init(value: Double) {
        self.dataValue = MLDataValue.double(value)
    }
    
}

let path = "/Users/molda_beta/Desktop/WWDC2018-Demos/CreateML.playground/Resources/"

enum DataSetFiles : String, CaseIterable {
    case x_test, x_train, y_test, y_train
}

enum HeaderFiles: String, CaseIterable {
    case activity_labels, features
}

var xCSVs = [DataSetFiles: [[Double]]]()
var yCSVs = [DataSetFiles: [Int]]()
var allHeaders = [HeaderFiles: [String]]()

let readData : (String) -> String? = { filename -> String? in
    let fullPath = "\(path)\(filename).txt"
    do {
        let string = try String(contentsOf: URL(fileURLWithPath: fullPath)).trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        return string
    } catch {
        return ""
    }
}

[DataSetFiles.x_train].forEach {
    if let csv = readData($0.rawValue)?.components(separatedBy: "\n")
        .map({ $0.components(separatedBy:CharacterSet.whitespaces).map { Double($0) ?? 0.0 }}) {
        xCSVs[$0] = csv
    }
}

xCSVs?[.x_train][0..<10]

let timestamp = xCSVs[.x_train].map { $0.compactMap { $0[0] } }!
let peakRate = xCSVs[.x_train].map { $0.compactMap { $0[2] } }!
let accumulatedYawRotation = xCSVs[.x_train].map { $0.compactMap { $0[3] } }!

[DataSetFiles.y_train].forEach {
    if let csv = readData($0.rawValue)?.components(separatedBy: "\n")
        .flatMap({ $0.components(separatedBy:CharacterSet.whitespaces)})
        .map({ Int($0) ?? -1 }) {
        yCSVs[$0] = csv
    }
}

let header = readData(HeaderFiles.features.rawValue)?
    .components(separatedBy: "\n")
    .filter { !$0.isEmpty }

var trainset = [String: MLDataValueConvertible]()
var testset = [String: MLDataValueConvertible]()

header?.forEach { feature in
    if let featureIndex = header?.index(of: feature) {
        let conversion = { (data: [[Double]]?) in
            return data?.map {
                $0.compactMap {
                    TennisDataSample(value: $0)
                }
            }
        }
        trainset[feature] = conversion(xCSVs[.x_train])!
        testset[feature] = conversion(xCSVs[.x_test])!
    }
}

trainset["MotionType"] = yCSVs[.y_train]
testset["MotionType"] = yCSVs[.y_test]

let data = readData("activity_labels.txt")
let activityLabelsCSV = data?.split(separator: "\n").map {
    $0.split(separator: " ")
}

let trainDataTable = try MLDataTable(dictionary: trainset)
let testDataTable = try MLDataTable(dictionary: testset)

let model = try MLRandomForestClassifier(trainingData: trainDataTable, targetColumn: "MotionType")

let eval = model.evaluation(on: testDataTable)

do {
    try model.write(to: URL(fileURLWithPath: "\(path)MLRandomForest.mlmodel"))
} catch {
    print(error)
}
 
let pred = model.predictions(from: testDataTable)
pred.doubles

//let evaluation = model.evaluation(on: testDataTable)

//let svc = try MLBoostedTreeClassifier(trainingData: trainDataTable, targetColumn: "MotionType")
//let e = svc.evaluation(on: testDataTable)

//let regModel = try MLRegressor(trainingData: trainDataTable, targetColumn: "MotionType")
//let regEv = regModel.evaluation(on: testDataTable)

//model.write(to: URL("save path"))

// MLRegressor - Runs all models and finds best for data
