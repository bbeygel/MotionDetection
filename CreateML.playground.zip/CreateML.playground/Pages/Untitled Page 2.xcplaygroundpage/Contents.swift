//: [Previous](@previous)

import CreateMLUI

let imageClassifier = MLImageClassifierBuilder().showInLiveView()
//: [Next](@next)
